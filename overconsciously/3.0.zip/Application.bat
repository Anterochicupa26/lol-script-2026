start zen.exe key.txt
